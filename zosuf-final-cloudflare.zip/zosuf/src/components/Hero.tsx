import React from 'react';
import { PageRoute } from '../types';
import {
  QrCode,
  Scan,
  Sparkles,
  ShieldCheck,
  Instagram,
  ArrowRight,
  Image as ImageIcon
} from 'lucide-react';

interface HeroProps {
  setActivePage: (page: PageRoute) => void;
}

export const Hero: React.FC<HeroProps> = ({ setActivePage }) => {
  return (
    <div className="relative overflow-hidden pt-8 pb-4 text-center">
      {/* Background glow flares */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-gradient-to-r from-violet-600/15 via-fuchsia-600/15 to-cyan-500/10 blur-[110px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
        {/* Top Eyebrow Tag */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-300 shadow-sm">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-slate-300 font-medium">100% Client-Side Browser Engine</span>
          <span className="text-slate-600">•</span>
          <a
            href="https://instagram.com/markzosuf"
            target="_blank"
            rel="noopener noreferrer"
            className="text-pink-400 hover:text-pink-300 flex items-center gap-1 font-semibold"
          >
            <Instagram className="w-3 h-3" />
            <span>@markzosuf</span>
          </a>
        </div>

        {/* Main Title */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-display font-extrabold text-white tracking-tight leading-[1.15]">
          Precision QR Codes &amp;{' '}
          <span className="bg-gradient-to-r from-purple-400 via-fuchsia-400 to-pink-400 bg-clip-text text-transparent">
            Image Studio
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
          Generate custom scannable QR codes for Wi-Fi, UPI, contacts, URLs, and images.
          Personalize colors, frames, and logos with zero accounts, no expiring links, and complete client-side privacy.
        </p>

        {/* Quick CTA Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            id="hero-create-qr-btn"
            onClick={() => {
              setActivePage('generator');
              const target = document.getElementById('qr-type-heading');
              if (target) target.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-purple-600 hover:from-violet-500 hover:to-fuchsia-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-purple-950/60 flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
          >
            <QrCode className="w-4 h-4" />
            <span>Create Custom QR Code</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            id="hero-scan-btn"
            onClick={() => {
              setActivePage('scanner');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="px-5 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs sm:text-sm font-medium flex items-center gap-2 transition-colors"
          >
            <Scan className="w-4 h-4 text-purple-400" />
            <span>Scan QR Code</span>
          </button>

          <button
            id="hero-image-tools-btn"
            onClick={() => {
              setActivePage('image-tools');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="px-5 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs sm:text-sm font-medium flex items-center gap-2 transition-colors"
          >
            <ImageIcon className="w-4 h-4 text-cyan-400" />
            <span>Image Studio</span>
          </button>
        </div>

        {/* Micro Trust Stats */}
        <div className="pt-4 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Zero Tracking or Cloud Storage</span>
          </span>
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>High-Res 1024px &amp; Vector SVG</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>16 QR Standard Protocols</span>
          </span>
        </div>
      </div>
    </div>
  );
};
